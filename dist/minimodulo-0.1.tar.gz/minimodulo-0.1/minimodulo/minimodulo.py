# Esto es un modulo con funciones que solicitas datos personales

def datos():
    # Solicitamos el numero
    nombre = input('Enter your name: ')
    edad = input("Enter your age: ")
    print(nombre,",", edad)
